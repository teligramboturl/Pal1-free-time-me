from .modules import appx_v1, classplus, visionias, testbook, pw

def main():
    print("Extractor module running...")
